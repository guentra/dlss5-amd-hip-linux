/* C ABI published by libdlss5_hip.so and forwarded by the PE trampoline dlss5_hip.dll.
   All calls are synchronous. One process-global model/history is serialized
   internally; callers must coordinate ownership, shutdown and library residency.
   Host arrays must be full-sized, packed and non-overlapping. Output is untouched
   on failure. Every failed run/frame call invalidates temporal history; every V1
   run invalidates it, even on success. Successful init/shutdown resets it.
   Failed init preserves the previous model. last_error is thread-local and its
   returned pointer stays valid only until the next API call on that thread. */
#ifndef DLSS5_CAPI_H
#define DLSS5_CAPI_H

#ifdef __cplusplus
extern "C" {
#endif

#define DLSS5_HIP_MAGIC 0x3150494853534C44ULL /* "DLSSHIP1" */
#define DLSS5_HIP_ENV "DLSS5_HIP_BRIDGE"
/* Same-process transport only, read through Wine's live Unix environment. */

typedef unsigned int dlss5_u32;

typedef struct Dlss5HipBridge {
    unsigned long long magic;
    int (*init)(const char *weights_dir, int gpu);
    int (*run)(const float *rgba1080, float *rgb1080, dlss5_u32 seed);
    void (*shutdown)(void);
    const char *(*last_error)(void);
} Dlss5HipBridge;

#ifndef DLSS5_CAPI_EXPORT
#define DLSS5_CAPI_EXPORT
#endif
DLSS5_CAPI_EXPORT int dlss5_init(const char *weights_dir, int gpu);
DLSS5_CAPI_EXPORT int dlss5_run(const float *rgba1080, float *rgb1080, dlss5_u32 seed);
DLSS5_CAPI_EXPORT void dlss5_shutdown(void);
DLSS5_CAPI_EXPORT const char *dlss5_last_error(void);

/* V2 uses a separate table, preserving the V1 ABI. Host pointers are packed
   1080p RGBA/RGB and a full motion rectangle (XY float32). flags bit0 selects
   display-sRGB; otherwise mode1 linear game color. reset invalidates history.
   Missing motion disables history for that call. Motion scales convert the
   caller's vector units into UV displacement; no sign or scale is guessed.
   Reprojection uses dlss5's float-only fast five-tap filter, not its alternate
   fixed-point texture/reciprocal-table implementation. */
#define DLSS5_HIP_FRAME_MAGIC 0x3250494853534C44ULL
#define DLSS5_HIP_FRAME_ENV "DLSS5_HIP_FRAME_BRIDGE"
typedef struct Dlss5Frame {
    dlss5_u32 struct_size, flags;
    const float *rgba;
    float *rgb;
    const float *motion;
    dlss5_u32 motion_width, motion_height;
    float motion_uv_scale_x, motion_uv_scale_y;
    dlss5_u32 seed, reset;
    float paper_white, transfer, color;
} Dlss5Frame;
/* V3 raw GPU-resident frame: in_handle/out_handle hold the packed game pixels
   (w x h x bytes-per-pixel) in one of three forms:
     - Win32 D3D12 shared handles of DEFAULT-heap linear buffers (default);
     - raw HIP device pointers, when flags bit1 is set (offline use);
     - host pointers to CPU-mapped D3D12 READBACK (in) / UPLOAD (out) buffers,
       when flags bit2 is set (in-game use: the bridge stages H2D/D2H around the
       fully GPU pipeline; bit1 and bit2 are mutually exclusive).
   The whole pipeline (pixel->RGBA, encode, network, decode, RGB->pixel) runs on
   the GPU. Output semantics match the CPU path exactly: RGB channels replaced,
   alpha bytes bit-exact from in. On bypass (non-finite or non-representable
   frame) out is a copy of in and the call still returns 0. */
#define DLSS5_HIP_RAW_FLAGS_SRGB 1u
#define DLSS5_HIP_RAW_FLAGS_DEV_PTRS 2u
#define DLSS5_HIP_RAW_FLAGS_HOST_PTRS 4u
typedef struct Dlss5FrameRaw {
    dlss5_u32 struct_size;
    void *in_handle;
    void *out_handle;
    dlss5_u32 width, height;
    dlss5_u32 dxgi_format; /* 28 RGBA8, 87 BGRA8, 11 R16 UNORM, 10 RGBA16 FLOAT */
    dlss5_u32 seed;
    dlss5_u32 flags;
    float paper_white, transfer, color;
    /* Import-cache generation: bump whenever the handles are recreated (kernel
       object handle values can be reused; the cache must not alias them). */
    dlss5_u32 handle_gen;
    /* Temporal-blend continuity token: any change resets the bridge's previous-frame
       blend buffer (e.g. the add-on's F6 bypass generation). 0 = no temporal blend
       continuity tracking by the caller. */
    dlss5_u32 temporal_gen;
} Dlss5FrameRaw;
typedef struct Dlss5HipFrameBridge {
    unsigned long long magic;
    int (*run_frame)(const Dlss5Frame *frame);
    int (*run_frame_raw_gpu)(const Dlss5FrameRaw *frame);
} Dlss5HipFrameBridge;
DLSS5_CAPI_EXPORT int dlss5_run_frame(const Dlss5Frame *frame);
DLSS5_CAPI_EXPORT int dlss5_run_frame_raw_gpu(const Dlss5FrameRaw *frame);

#define DLSS5_HIP_DEVICE_MAGIC 0x3349504853534C44ULL
#define DLSS5_HIP_DEVICE_ENV "DLSS5_HIP_DEVICE_BRIDGE"
typedef struct Dlss5HipDeviceBridge {
    unsigned long long magic;
    int (*find_device)(const char *exact_name);
} Dlss5HipDeviceBridge;
/* Unique exact name match only. Ambiguous or absent adapters return -1. */
DLSS5_CAPI_EXPORT int dlss5_find_device(const char *exact_name);

#ifdef __cplusplus
}
#endif
#endif
